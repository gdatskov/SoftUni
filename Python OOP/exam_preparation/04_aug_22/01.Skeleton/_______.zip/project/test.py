asd = [1 for _ in range(0)]
print(asd)
print(asd is None)