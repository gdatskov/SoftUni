asd = [1 for _ in range(0)][0]
print(asd)