class Controller:
    def __init__(self):
        self.cars = []
        self.drivers = []
        self.races = []