# from project.car.car import Car


class Driver:
    def __init__(self, name):
        self.name = name
        self.car = None
        self.__number_of_wins = 0

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if value.strip() == "":
            raise ValueError("Name should contain at least one character!")
        self.__name = value

    @property
    def car(self):
        return self.__car

    @car.setter
    def car(self, value):
        if self.car is None:
            self.__car = value

    @property
    def number_of_wins(self):
        return self.__number_of_wins

    def add_win(self):
        self.__number_of_wins += 1
