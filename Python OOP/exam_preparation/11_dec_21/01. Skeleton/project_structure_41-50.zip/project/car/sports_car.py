from project.car.car import Car


class SportsCar(Car):
    __MINIMUM_LIMIT = 400
    __MAXIMUM_LIMIT = 600

    @property
    def speed_limit(self):
        return self.__speed_limit

    @speed_limit.setter
    def speed_limit(self, value):
        if value > self.__MAXIMUM_LIMIT:
            self.__speed_limit = self.__MAXIMUM_LIMIT
        elif value < self.__MINIMUM_LIMIT:
            self.__speed_limit = self.__MINIMUM_LIMIT
        else:
            self.__speed_limit = value
