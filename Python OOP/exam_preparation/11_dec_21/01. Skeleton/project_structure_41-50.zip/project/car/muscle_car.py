from project.car.car import Car


class MuscleCar(Car):
    __MINIMUM_LIMIT = 250
    __MAXIMUM_LIMIT = 450

    @property
    def speed_limit(self):
        return self.__speed_limit

    @speed_limit.setter
    def speed_limit(self, value):
        if value > self.__MAXIMUM_LIMIT:
            self.__speed_limit = self.__MAXIMUM_LIMIT
        elif value < self.__MINIMUM_LIMIT:
            self.__speed_limit = self.__MINIMUM_LIMIT
        else:
            self.__speed_limit = value
