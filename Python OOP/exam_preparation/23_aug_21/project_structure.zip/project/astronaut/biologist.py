from project.astronaut.astronaut import Astronaut


class Biologist(Astronaut):
    __DEFAULT_OXYGEN = 70

    def __init__(self, name):
        super().__init__(name, self.__DEFAULT_OXYGEN)
