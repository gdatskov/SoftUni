from abc import ABC, abstractmethod


class Horse(ABC):
    def __init__(self, name, speed):
        """
        Keep in mind that each horse breed has a different maximum speed,
        which cannot be exceeded. If the given horse speed exceeds the maximum,
        raise a ValueError with the message: "Horse speed is too high!"
        """
        self.name = name
        self.speed = speed
        self.is_taken = False
        self.jockey = None

    @abstractmethod
    def train(self):
        """
        Each horse can be additionally trained during the race days.
        When a horse is trained, it increases its speed by a value depending on its type.
        During training, a horse cannot exceed its maximum speed
        (just set its speed to the maximum one without raising an error).
        """
        pass

